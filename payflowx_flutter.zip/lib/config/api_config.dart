class ApiConfig {
  static const String baseUrl = 'https://api.payflow.example.com';
  static const Duration timeout = Duration(seconds: 30);

  // Auth
  static const String login = '/auth/login';
  static const String register = '/auth/register';
  static const String verifyOtp = '/auth/verify-otp';
  static const String resendOtp = '/auth/resend-otp';
  static const String logout = '/auth/logout';

  // User
  static const String profile = '/user/profile';
  static const String updateProfile = '/user/profile';

  // Transactions
  static const String transactions = '/transactions';
  static String transactionDetail(String id) => '/transactions/$id';

  // API Keys
  static const String apiKeys = '/api-keys';
  static String apiKeyDetail(String id) => '/api-keys/$id';

  // Webhooks
  static const String webhooks = '/webhooks';
  static String webhookDetail(String id) => '/webhooks/$id';
}