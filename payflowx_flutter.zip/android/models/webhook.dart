class Webhook {
  final String id;
  final String url;
  final List<String> events;
  final bool isActive;
  final DateTime createdAt;

  Webhook({
    required this.id,
    required this.url,
    required this.events,
    required this.isActive,
    required this.createdAt,
  });

  factory Webhook.fromJson(Map<String, dynamic> json) {
    return Webhook(
      id: json['id']?.toString() ?? '',
      url: json['url'] ?? '',
      events: (json['events'] as List?)?.map((e) => e.toString()).toList() ?? [],
      isActive: json['is_active'] ?? true,
      createdAt:
          DateTime.tryParse(json['created_at'] ?? '') ?? DateTime.now(),
    );
  }
}