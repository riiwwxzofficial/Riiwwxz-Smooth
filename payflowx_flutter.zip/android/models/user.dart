class User {
  final String id;
  final String name;
  final String email;
  final String? phone;
  final double balance;
  final bool isVerified;

  User({
    required this.id,
    required this.name,
    required this.email,
    this.phone,
    this.balance = 0,
    this.isVerified = false,
  });

  factory User.fromJson(Map<String, dynamic> json) {
    return User(
      id: json['id']?.toString() ?? '',
      name: json['name'] ?? '',
      email: json['email'] ?? '',
      phone: json['phone'],
      balance: (json['balance'] ?? 0).toDouble(),
      isVerified: json['is_verified'] ?? json['isVerified'] ?? false,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'email': email,
        'phone': phone,
        'balance': balance,
        'is_verified': isVerified,
      };
}