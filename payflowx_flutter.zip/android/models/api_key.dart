class ApiKey {
  final String id;
  final String? name;
  final String? key;
  final String? preview;
  final bool? isActive;
  final DateTime createdAt;

  ApiKey({
    required this.id,
    this.name,
    this.key,
    this.preview,
    this.isActive,
    required this.createdAt,
  });

  factory ApiKey.fromJson(Map<String, dynamic> json) {
    return ApiKey(
      id: json['id']?.toString() ?? '',
      name: json['name'],
      key: json['key'],
      preview: json['preview'],
      isActive: json['is_active'] ?? json['isActive'] ?? true,
      createdAt:
          DateTime.tryParse(json['created_at'] ?? '') ?? DateTime.now(),
    );
  }
}