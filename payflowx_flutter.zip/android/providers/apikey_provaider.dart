import 'package:flutter/material.dart';
import '../models/api_key.dart';
import '../services/apikey_service.dart';

class ApiKeyProvider extends ChangeNotifier {
  final _service = ApiKeyService();

  List<ApiKey> _keys = [];
  bool _isLoading = false;
  String? _error;

  List<ApiKey> get keys => _keys;
  bool get isLoading => _isLoading;
  String? get error => _error;

  Future<void> load() async {
    _isLoading = true;
    _error = null;
    notifyListeners();
    try {
      _keys = await _service.list();
    } catch (e) {
      _error = e.toString();
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<ApiKey?> create(String name) async {
    try {
      final key = await _service.create(name);
      await load();
      return key;
    } catch (e) {
      _error = e.toString();
      notifyListeners();
      return null;
    }
  }

  Future<bool> delete(String id) async {
    try {
      await _service.delete(id);
      _keys.removeWhere((k) => k.id == id);
      notifyListeners();
      return true;
    } catch (e) {
      _error = e.toString();
      notifyListeners();
      return false;
    }
  }
}