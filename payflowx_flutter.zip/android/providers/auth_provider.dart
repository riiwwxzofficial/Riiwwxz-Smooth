import 'package:flutter/material.dart';
import '../models/user.dart';
import '../services/api_client.dart';
import '../services/auth_service.dart';
import '../services/storage_service.dart';
import '../services/user_service.dart';

class AuthProvider extends ChangeNotifier {
  final _auth = AuthService();
  final _userSvc = UserService();

  User? _user;
  bool _isLoading = false;
  String? _error;
  String? _pendingEmail;

  User? get user => _user;
  bool get isLoading => _isLoading;
  String? get error => _error;
  bool get isLoggedIn => _user != null;
  String? get pendingEmail => _pendingEmail;

  Future<bool> login(String email, String password) async {
    _isLoading = true;
    _error = null;
    notifyListeners();
    try {
      final result = await _auth.login(email, password);
      if (result.requiresOtp) {
        _pendingEmail = email;
        _isLoading = false;
        notifyListeners();
        return false; // butuh OTP
      }
      ApiClient().setToken(result.token);
      await StorageService.saveToken(result.token);
      _user = result.user;
      _isLoading = false;
      notifyListeners();
      return true;
    } catch (e) {
      _error = e.toString();
      _isLoading = false;
      notifyListeners();
      return false;
    }
  }

  Future<bool> verifyOtp(String otp) async {
    if (_pendingEmail == null) return false;
    _isLoading = true;
    _error = null;
    notifyListeners();
    try {
      final result = await _auth.verifyOtp(_pendingEmail!, otp);
      ApiClient().setToken(result.token);
      await StorageService.saveToken(result.token);
      _user = result.user;
      _pendingEmail = null;
      _isLoading = false;
      notifyListeners();
      return true;
    } catch (e) {
      _error = e.toString();
      _isLoading = false;
      notifyListeners();
      return false;
    }
  }

  Future<bool> register(String name, String email, String password) async {
    _isLoading = true;
    _error = null;
    notifyListeners();
    try {
      await _auth.register(name, email, password);
      _isLoading = false;
      notifyListeners();
      return true;
    } catch (e) {
      _error = e.toString();
      _isLoading = false;
      notifyListeners();
      return false;
    }
  }

  Future<void> refreshProfile() async {
    try {
      _user = await _userSvc.getProfile();
      notifyListeners();
    } catch (_) {}
  }

  Future<void> logout() async {
    try {
      await _auth.logout();
    } catch (_) {}
    await StorageService.clear();
    ApiClient().setToken(null);
    _user = null;
    notifyListeners();
  }

  Future<void> restoreSession() async {
    final token = await StorageService.getToken();
    if (token != null) {
      ApiClient().setToken(token);
      await refreshProfile();
    }
  }
}