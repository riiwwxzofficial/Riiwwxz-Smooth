import '../config/api_config.dart';
import '../models/user.dart';
import 'api_client.dart';

class UserService {
  final _api = ApiClient();

  Future<User> getProfile() async {
    final res = await _api.get(ApiConfig.profile);
    final data = res['data'] ?? res;
    return User.fromJson(data);
  }

  Future<User> updateProfile(Map<String, dynamic> body) async {
    final res = await _api.put(ApiConfig.updateProfile, body: body);
    final data = res['data'] ?? res;
    return User.fromJson(data);
  }
}