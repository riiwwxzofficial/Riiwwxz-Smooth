import '../config/api_config.dart';
import '../models/transaction.dart';
import 'api_client.dart';

class TransactionService {
  final _api = ApiClient();

  Future<List<Transaction>> list() async {
    final res = await _api.get(ApiConfig.transactions);
    final list = (res['data'] ?? res['transactions'] ?? res) as List;
    return list
        .map((e) => Transaction.fromJson(e as Map<String, dynamic>))
        .toList();
  }

  Future<Transaction> create({
    required String type,
    required double amount,
    String? description,
  }) async {
    final res = await _api.post(ApiConfig.transactions, body: {
      'type': type,
      'amount': amount,
      'description': description,
    });
    return Transaction.fromJson((res['data'] ?? res) as Map<String, dynamic>);
  }

  Future<void> delete(String id) async {
    await _api.delete(ApiConfig.transactionDetail(id));
  }
}