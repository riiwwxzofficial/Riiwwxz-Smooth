import '../config/api_config.dart';
import '../models/user.dart';
import 'api_client.dart';

class AuthResult {
  final String token;
  final User user;
  final bool requiresOtp;
  AuthResult({required this.token, required this.user, this.requiresOtp = false});
}

class AuthService {
  final _api = ApiClient();

  Future<AuthResult> login(String email, String password) async {
    final res = await _api.post(ApiConfig.login, body: {
      'email': email,
      'password': password,
    });
    final data = res['data'] ?? res;
    return AuthResult(
      token: data['token'] ?? '',
      user: User.fromJson(data['user'] ?? {}),
      requiresOtp: data['requires_otp'] ?? false,
    );
  }

  Future<bool> register(String name, String email, String password) async {
    await _api.post(ApiConfig.register, body: {
      'name': name,
      'email': email,
      'password': password,
    });
    return true;
  }

  Future<AuthResult> verifyOtp(String email, String otp) async {
    final res = await _api.post(ApiConfig.verifyOtp, body: {
      'email': email,
      'otp': otp,
    });
    final data = res['data'] ?? res;
    return AuthResult(
      token: data['token'] ?? '',
      user: User.fromJson(data['user'] ?? {}),
    );
  }

  Future<bool> resendOtp(String email) async {
    await _api.post(ApiConfig.resendOtp, body: {'email': email});
    return true;
  }

  Future<void> logout() async {
    await _api.post(ApiConfig.logout);
  }
}