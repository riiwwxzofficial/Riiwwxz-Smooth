import '../config/api_config.dart';
import '../models/api_key.dart';
import 'api_client.dart';

class ApiKeyService {
  final _api = ApiClient();

  Future<List<ApiKey>> list() async {
    final res = await _api.get(ApiConfig.apiKeys);
    final list = (res['data'] ?? res['keys'] ?? res) as List;
    return list
        .map((e) => ApiKey.fromJson(e as Map<String, dynamic>))
        .toList();
  }

  Future<ApiKey> create(String name) async {
    final res = await _api.post(ApiConfig.apiKeys, body: {'name': name});
    return ApiKey.fromJson((res['data'] ?? res) as Map<String, dynamic>);
  }

  Future<void> delete(String id) async {
    await _api.delete(ApiConfig.apiKeyDetail(id));
  }
}