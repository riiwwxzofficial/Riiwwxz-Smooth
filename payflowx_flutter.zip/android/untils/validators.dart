class Validators {
  static String? email(String? v) {
    if (v == null || v.isEmpty) return 'Email wajib diisi';
    final re = RegExp(r'^[\w\.-]+@[\w\.-]+\.\w+$');
    if (!re.hasMatch(v)) return 'Format email tidak valid';
    return null;
  }

  static String? password(String? v) {
    if (v == null || v.isEmpty) return 'Password wajib diisi';
    if (v.length < 6) return 'Password minimal 6 karakter';
    return null;
  }

  static String? name(String? v) {
    if (v == null || v.isEmpty) return 'Nama wajib diisi';
    if (v.length < 3) return 'Nama minimal 3 karakter';
    return null;
  }

  static String? otp(String? v) {
    if (v == null || v.isEmpty) return 'Kode OTP wajib diisi';
    if (v.length != 6) return 'Kode OTP harus 6 digit';
    return null;
  }

  static String? amount(String? v) {
    if (v == null || v.isEmpty) return 'Jumlah wajib diisi';
    final n = double.tryParse(v.replaceAll('.', ''));
    if (n == null || n <= 0) return 'Jumlah tidak valid';
    return null;
  }
}