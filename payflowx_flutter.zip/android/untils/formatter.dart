import 'package:intl/intl.dart';

class Formatter {
  static final _currency =
      NumberFormat.currency(locale: 'id_ID', symbol: 'Rp ', decimalDigits: 0);
  static final _date = DateFormat('dd MMM yyyy, HH:mm', 'id_ID');
  static final _shortDate = DateFormat('dd MMM yyyy', 'id_ID');
  static final _time = DateFormat('HH:mm:ss', 'id_ID');

  static String currency(num value) => _currency.format(value);
  static String date(DateTime value) => _date.format(value);
  static String shortDate(DateTime value) => _shortDate.format(value);
  static String time(DateTime value) => _time.format(value);
}