import 'package:flutter/material.dart';
import '../config/theme.dart';

/// Widget indikator loading yang reusable.
///
/// Pemakaian:
/// ```dart
/// // 1. Full screen (dipakai di SplashScreen / saat blocking)
/// LoadingIndicator.fullScreen(message: 'Memuat data...');
///
/// // 2. Inline (di tengah halaman / list kosong)
/// const LoadingIndicator(message: 'Mengambil data');
///
/// // 3. Overlay di atas konten (misal saat submit form)
/// Stack(
///   children: [
///     MyContent(),
///     if (loading) const LoadingIndicator.overlay(),
///   ],
/// )
///
/// // 4. Untuk tombol
/// ElevatedButton(
///   onPressed: loading ? null : _submit,
///   child: loading
///       ? const LoadingIndicator.button()
///       : const Text('Simpan'),
/// )
/// ```
class LoadingIndicator extends StatelessWidget {
  /// Pesan opsional di bawah spinner.
  final String? message;

  /// Ukuran spinner (default 36).
  final double size;

  /// Warna spinner (default AppTheme.primary).
  final Color? color;

  /// Padding di sekitar konten.
  final EdgeInsetsGeometry padding;

  const LoadingIndicator({
    super.key,
    this.message,
    this.size = 36,
    this.color,
    this.padding = const EdgeInsets.all(16),
  });

  /// Varian full-screen: latar belakang putih + konten di tengah.
  /// Cocok untuk SplashScreen atau saat memblokir seluruh layar.
  factory LoadingIndicator.fullScreen({
    Key? key,
    String? message,
    double size = 48,
    Color? color,
  }) {
    return _FullScreenLoading(
      key: key,
      message: message,
      size: size,
      color: color,
    );
  }

  /// Varian overlay: transparan gelap di atas konten, spinner di tengah.
  /// Cocok dipasang di dalam Stack saat submit form.
  factory LoadingIndicator.overlay({
    Key? key,
    String? message,
    double size = 40,
    Color? color,
  }) {
    return _OverlayLoading(
      key: key,
      message: message,
      size: size,
      color: color,
    );
  }

  /// Varian kecil untuk di dalam tombol.
  factory LoadingIndicator.button({
    Key? key,
    double size = 20,
    Color color = Colors.white,
  }) {
    return SizedBox(
      key: key,
      width: size,
      height: size,
      child: CircularProgressIndicator(
        strokeWidth: 2.5,
        valueColor: AlwaysStoppedAnimation<Color>(color),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: padding,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          SizedBox(
            width: size,
            height: size,
            child: CircularProgressIndicator(
              strokeWidth: 3,
              valueColor: AlwaysStoppedAnimation<Color>(
                color ?? AppTheme.primary,
              ),
            ),
          ),
          if (message != null) ...[
            const SizedBox(height: 12),
            Text(
              message!,
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 13,
                color: Colors.grey[700],
              ),
            ),
          ],
        ],
      ),
    );
  }
}

// =====================================================================
// Implementasi varian full-screen
// =====================================================================
class _FullScreenLoading extends StatelessWidget {
  final String? message;
  final double size;
  final Color? color;

  const _FullScreenLoading({
    super.key,
    this.message,
    this.size = 48,
    this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Center(
        child: LoadingIndicator(
          message: message,
          size: size,
          color: color,
        ),
      ),
    );
  }
}

// =====================================================================
// Implementasi varian overlay
// =====================================================================
class _OverlayLoading extends StatelessWidget {
  final String? message;
  final double size;
  final Color? color;

  const _OverlayLoading({
    super.key,
    this.message,
    this.size = 40,
    this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Positioned.fill(
      child: ColoredBox(
        color: Colors.black.withOpacity(0.35),
        child: Center(
          child: Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(12),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.1),
                  blurRadius: 10,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: LoadingIndicator(
              message: message,
              size: size,
              color: color,
            ),
          ),
        ),
      ),
    );
  }
}