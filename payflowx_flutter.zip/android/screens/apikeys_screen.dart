import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/apikey_provider.dart';
import '../widgets/apikey_card.dart';

class ApiKeysScreen extends StatefulWidget {
  const ApiKeysScreen({super.key});
  @override
  State<ApiKeysScreen> createState() => _ApiKeysScreenState();
}

class _ApiKeysScreenState extends State<ApiKeysScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<ApiKeyProvider>().load();
    });
  }

  Future<void> _createKey() async {
    final nameCtrl = TextEditingController();
    final name = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Buat API Key Baru'),
        content: TextField(
          controller: nameCtrl,
          decoration: const InputDecoration(labelText: 'Nama Key'),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('Batal')),
          ElevatedButton(
            onPressed: () {
              if (nameCtrl.text.trim().isNotEmpty) {
                Navigator.pop(ctx, nameCtrl.text.trim());
              }
            },
            child: const Text('Buat'),
          ),
        ],
      ),
    );

    if (name != null && mounted) {
      final provider = context.read<ApiKeyProvider>();
      final newKey = await provider.create(name);
      if (newKey != null && mounted) {
        showDialog(
          context: context,
          builder: (ctx) => AlertDialog(
            title: const Text('API Key Baru'),
            content: SelectableText(
              newKey.key ?? '',
              style: const TextStyle(
                  fontFamily: 'monospace', fontSize: 13),
            ),
            actions: [
              TextButton(
                  onPressed: () => Navigator.pop(ctx),
                  child: const Text('Tutup')),
            ],
          ),
        );
      }
    }
  }

  Future<void> _confirmDelete(String id) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Hapus API Key?'),
        content: const Text('Key yang dihapus tidak dapat digunakan lagi.'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('Batal')),
          ElevatedButton(
            onPressed: () => Navigator.pop(ctx, true),
            style:
                ElevatedButton.styleFrom(backgroundColor: Colors.red),
            child: const Text('Hapus'),
          ),
        ],
      ),
    );

    if (confirm == true && mounted) {
      await context.read<ApiKeyProvider>().delete(id);
    }
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<ApiKeyProvider>();

    return Scaffold(
      appBar: AppBar(
        title: const Text('API Keys'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: () => provider.load(),
          ),
        ],
      ),
      body: provider.isLoading
          ? const Center(child: CircularProgressIndicator())
          : provider.keys.isEmpty
              ? const Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.key_off, size: 64, color: Colors.grey),
                      SizedBox(height: 16),
                      Text('Belum ada API Key',
                          style:
                              TextStyle(color: Colors.grey, fontSize: 16)),
                    ],
                  ),
                )
              : RefreshIndicator(
                  onRefresh: () => provider.load(),
                  child: ListView.separated(
                    padding: const EdgeInsets.all(16),
                    itemCount: provider.keys.length,
                    separatorBuilder: (_, __) =>
                        const SizedBox(height: 8),
                    itemBuilder: (context, i) {
                      final key = provider.keys[i];
                      return ApiKeyCard(
                        apiKey: key,
                        onDelete: () => _confirmDelete(key.id),
                      );
                    },
                  ),
                ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _createKey,
        icon: const Icon(Icons.add),
        label: const Text('Buat Key'),
      ),
    );
  }
}