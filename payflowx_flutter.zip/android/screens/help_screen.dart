import 'package:flutter/material.dart';

class HelpScreen extends StatelessWidget {
  const HelpScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final faqs = [
      {
        'q': 'Bagaimana cara top up saldo?',
        'a': 'Buka Beranda → Top Up → pilih metode pembayaran.',
      },
      {
        'q': 'Apa itu API Key?',
        'a': 'API Key digunakan untuk mengakses layanan PayFlow dari aplikasi Anda.',
      },
      {
        'q': 'Bagaimana cara menghubungi CS?',
        'a': 'Hubungi support@payflow.example.com atau via live chat.',
      },
    ];

    return Scaffold(
      appBar: AppBar(title: const Text('Bantuan')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('FAQ',
              style:
                  TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          ...faqs.map((f) => Card(
                child: ExpansionTile(
                  title: Text(f['q']!,
                      style: const TextStyle(fontSize: 14)),
                  children: [
                    Padding(
                      padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                      child: Text(f['a']!,
                          style: TextStyle(
                              fontSize: 13, color: Colors.grey[700])),
                    ),
                  ],
                ),
              )),
        ],
      ),
    );
  }
}