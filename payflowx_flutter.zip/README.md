# PayFlow - Payment Gateway & API Management

Sistem payment gateway dengan dukungan API key management, OAuth Google, dan integrasi Midtrans/Xendit.

## Quick Start
```bash
cd backend && npm install && npm run dev